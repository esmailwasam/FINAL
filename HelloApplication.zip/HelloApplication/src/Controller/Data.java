package Controller;

public class Data {

    private final Object col1;
    private final Object col2;
    private final Object col3;
    private final Object col4;
    private final Object col5;

    public Object getCol1() {
        return col1;
    }

    public Object getCol2() {
        return col2;
    }

    public Object getCol3() {
        return col3;
    }

    public Object getCol4() {
        return col4;
    }

    public Object getCol5() {
        return col5;
    }

    public Data(Object col1 , Object col2 , Object col3 , Object col4 , Object col5) {
        this.col1 = col1;
        this.col2 = col2;
        this.col3 = col3;
        this.col4 = col4;
        this.col5 = col5;
    }


}